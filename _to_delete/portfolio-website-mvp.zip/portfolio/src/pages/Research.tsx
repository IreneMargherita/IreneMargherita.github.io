import { usePageTitle } from '../hooks/usePageTitle';
import { research } from '../data/content';
import type { Publication } from '../data/content';
import SectionHeading from '../components/SectionHeading';

const TYPE_BADGE: Record<Publication['type'], string> = {
  journal: 'text-syntax-blue border-syntax-blue/40 bg-syntax-blue/10',
  conference: 'text-syntax-violet border-syntax-violet/40 bg-syntax-violet/10',
  preprint: 'text-syntax-orange border-syntax-orange/40 bg-syntax-orange/10',
  article: 'text-signal border-signal/40 bg-signal/10',
};

export default function Research() {
  usePageTitle('Research & Publications');

  return (
    <section className="section">
      <div className="container-content">
        <SectionHeading code="04. research" title="Research & publications" lead={research.intro} />

        <div className="max-w-3xl space-y-4">
          {research.publications.map((pub) => (
            <article key={pub.title} className="card card-hover p-5">
              <div className="mb-2 flex flex-wrap items-center gap-2">
                <span className={`rounded-full border px-2 py-0.5 font-mono text-[11px] ${TYPE_BADGE[pub.type]}`}>
                  {pub.type}
                </span>
                <span className="font-mono text-xs text-mist-600">{pub.year}</span>
              </div>
              <h3 className="text-[15px] font-semibold leading-snug text-mist-100">{pub.title}</h3>
              <p className="mt-1 font-mono text-xs text-mist-400">
                {pub.authors} · <span className="italic">{pub.venue}</span>
              </p>
              {pub.note && <p className="mt-2 text-[13px] text-mist-600">{pub.note}</p>}
              {pub.link && (
                <a href={pub.link} target="_blank" rel="noreferrer" className="link mt-2 inline-block font-mono text-xs">
                  read →
                </a>
              )}
            </article>
          ))}
        </div>

        <div className="mt-14 max-w-3xl">
          <h3 className="mb-4 font-mono text-sm text-sunshine-500">
            <span className="text-sunshine-700">{'//'}</span> talks
          </h3>
          <ul className="space-y-3">
            {research.talks.map((t) => (
              <li key={t.title} className="card flex flex-wrap items-baseline justify-between gap-2 p-4">
                <div>
                  <p className="text-sm font-medium text-mist-100">{t.title}</p>
                  <p className="font-mono text-xs text-mist-400">{t.event}</p>
                </div>
                <span className="font-mono text-xs text-mist-600">{t.year}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}
